package com.thbs.domainservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DomainServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
