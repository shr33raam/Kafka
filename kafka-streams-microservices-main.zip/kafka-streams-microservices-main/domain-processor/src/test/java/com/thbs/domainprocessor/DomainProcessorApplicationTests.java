package com.thbs.domainprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DomainProcessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
